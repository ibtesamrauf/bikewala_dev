<select name='recountry' id='recountry'>
<option value="Afghanistan" <?php if($redefaultCountry == "Afghanistan") print 'selected="selected"'; ?> >Afghanistan</option>
<option value="&Aring;land Islands" <?php if($redefaultCountry == "&Aring;land Islands") print 'selected="selected"'; ?> >&Aring;land Islands</option>
<option value="Albania" <?php if($redefaultCountry == "Albania") print 'selected="selected"'; ?> >Albania</option>
<option value="Algeria" <?php if($redefaultCountry == "Algeria") print 'selected="selected"'; ?> >Algeria</option>
<option value="American Samoa" <?php if($redefaultCountry == "American Samoa") print 'selected="selected"'; ?> >American Samoa</option>
<option value="Andorra" <?php if($redefaultCountry == "Andorra") print 'selected="selected"'; ?> >Andorra</option>
<option value="Angola" <?php if($redefaultCountry == "Angola") print 'selected="selected"'; ?> >Angola</option>
<option value="Anguilla" <?php if($redefaultCountry == "Anguilla") print 'selected="selected"'; ?> >Anguilla</option>

<option value="Antarctica" <?php if($redefaultCountry == "Antarctica") print 'selected="selected"'; ?> >Antarctica</option>
<option value="Antigua and Barbuda" <?php if($redefaultCountry == "Antigua and Barbuda") print 'selected="selected"'; ?> >Antigua and Barbuda</option>
<option value="Argentina" <?php if($redefaultCountry == "Argentina") print 'selected="selected"'; ?> >Argentina</option>
<option value="Armenia" <?php if($redefaultCountry == "Armenia") print 'selected="selected"'; ?> >Armenia</option>
<option value="Aruba" <?php if($redefaultCountry == "Aruba") print 'selected="selected"'; ?> >Aruba</option>
<option value="Australia" <?php if($redefaultCountry == "Australia") print 'selected="selected"'; ?> >Australia</option>
<option value="Austria" <?php if($redefaultCountry == "Austria") print 'selected="selected"'; ?> >Austria</option>
<option value="Azerbaijan" <?php if($redefaultCountry == "Azerbaijan") print 'selected="selected"'; ?> >Azerbaijan</option>

<option value="Bahamas" <?php if($redefaultCountry == "Bahamas") print 'selected="selected"'; ?> >Bahamas</option>
<option value="Bahrain" <?php if($redefaultCountry == "Bahrain") print 'selected="selected"'; ?> >Bahrain</option>
<option value="Bangladesh" <?php if($redefaultCountry == "Bangladesh") print 'selected="selected"'; ?> >Bangladesh</option>
<option value="Barbados" <?php if($redefaultCountry == "Barbados") print 'selected="selected"'; ?> >Barbados</option>
<option value="Belarus" <?php if($redefaultCountry == "Belarus") print 'selected="selected"'; ?> >Belarus</option>
<option value="Belgium" <?php if($redefaultCountry == "Belgium") print 'selected="selected"'; ?> >Belgium</option>
<option value="Belize" <?php if($redefaultCountry == "Belize") print 'selected="selected"'; ?> >Belize</option>
<option value="Benin" <?php if($redefaultCountry == "Benin") print 'selected="selected"'; ?> >Benin</option>
<option value="Bermuda" <?php if($redefaultCountry == "Bermuda") print 'selected="selected"'; ?> >Bermuda</option>

<option value="Bhutan" <?php if($redefaultCountry == "Bhutan") print 'selected="selected"'; ?> >Bhutan</option>
<option value="Bolivia" <?php if($redefaultCountry == "Bolivia") print 'selected="selected"'; ?> >Bolivia</option>
<option value="Bosnia and Herzegovina" <?php if($redefaultCountry == "Bosnia and Herzegovina") print 'selected="selected"'; ?> >Bosnia and Herzegovina</option>
<option value="Botswana" <?php if($redefaultCountry == "Botswana") print 'selected="selected"'; ?> >Botswana</option>
<option value="Bouvet Island" <?php if($redefaultCountry == "Bouvet Island") print 'selected="selected"'; ?> >Bouvet Island</option>
<option value="Brazil" <?php if($redefaultCountry == "Brazil") print 'selected="selected"'; ?> >Brazil</option>
<option value="British Indian Ocean territory" <?php if($redefaultCountry == "British Indian Ocean territory") print 'selected="selected"'; ?> >British Indian Ocean territory</option>
<option value="Brunei Darussalam" <?php if($redefaultCountry == "Brunei Darussalam") print 'selected="selected"'; ?> >Brunei Darussalam</option>
<option value="Bulgaria" <?php if($redefaultCountry == "Bulgaria") print 'selected="selected"'; ?> >Bulgaria</option>

<option value="Burkina Faso" <?php if($redefaultCountry == "Burkina Faso") print 'selected="selected"'; ?> >Burkina Faso</option>
<option value="Burundi" <?php if($redefaultCountry == "Burundi") print 'selected="selected"'; ?> >Burundi</option>
<option value="Cambodia" <?php if($redefaultCountry == "Cambodia") print 'selected="selected"'; ?> >Cambodia</option>
<option value="Cameroon" <?php if($redefaultCountry == "Cameroon") print 'selected="selected"'; ?> >Cameroon</option>
<option value="Canada" <?php if($redefaultCountry == "Canada") print 'selected="selected"'; ?> >Canada</option>
<option value="Cape Verde" <?php if($redefaultCountry == "Cape Verde") print 'selected="selected"'; ?> >Cape Verde</option>
<option value="Cayman Islands" <?php if($redefaultCountry == "Cayman Islands") print 'selected="selected"'; ?> >Cayman Islands</option>
<option value="Central African Republic" <?php if($redefaultCountry == "Central African Republic") print 'selected="selected"'; ?> >Central African Republic</option>

<option value="Chad" <?php if($redefaultCountry == "Chad") print 'selected="selected"'; ?> >Chad</option>
<option value="Chile" <?php if($redefaultCountry == "Chile") print 'selected="selected"'; ?> >Chile</option>
<option value="China" <?php if($redefaultCountry == "China") print 'selected="selected"'; ?> >China</option>
<option value="Christmas Island" <?php if($redefaultCountry == "Christmas Island") print 'selected="selected"'; ?> >Christmas Island</option>
<option value="Cocos (Keeling) Islands" <?php if($redefaultCountry == "Cocos (Keeling) Islands") print 'selected="selected"'; ?> >Cocos (Keeling) Islands</option>
<option value="Colombia" <?php if($redefaultCountry == "Colombia") print 'selected="selected"'; ?> >Colombia</option>
<option value="Comoros" <?php if($redefaultCountry == "Comoros") print 'selected="selected"'; ?> >Comoros</option>
<option value="Congo" <?php if($redefaultCountry == "Congo") print 'selected="selected"'; ?> >Congo</option>
<option value="Congo, Democratic Republic" <?php if($redefaultCountry == "Congo, Democratic Republic") print 'selected="selected"'; ?> >Congo, Democratic Republic</option>

<option value="Cook Islands" <?php if($redefaultCountry == "Cook Islands") print 'selected="selected"'; ?> >Cook Islands</option>
<option value="Costa Rica" <?php if($redefaultCountry == "Costa Rica") print 'selected="selected"'; ?> >Costa Rica</option>
<option value="C&ocirc;te d'Ivoire (Ivory Coast)" <?php if($redefaultCountry == "C&ocirc;te d'Ivoire (Ivory Coast)") print 'selected="selected"'; ?> >C&ocirc;te d'Ivoire (Ivory Coast)</option>
<option value="Croatia (Hrvatska)" <?php if($redefaultCountry == "Croatia (Hrvatska)") print 'selected="selected"'; ?> >Croatia (Hrvatska)</option>
<option value="Cuba" <?php if($redefaultCountry == "Cuba") print 'selected="selected"'; ?> >Cuba</option>
<option value="Cyprus" <?php if($redefaultCountry == "Cyprus") print 'selected="selected"'; ?> >Cyprus</option>
<option value="Czech Republic" <?php if($redefaultCountry == "Czech Republic") print 'selected="selected"'; ?> >Czech Republic</option>
<option value="Denmark" <?php if($redefaultCountry == "Denmark") print 'selected="selected"'; ?> >Denmark</option>

<option value="Djibouti" <?php if($redefaultCountry == "Djibouti") print 'selected="selected"'; ?> >Djibouti</option>
<option value="Dominica" <?php if($redefaultCountry == "Dominica") print 'selected="selected"'; ?> >Dominica</option>
<option value="Dominican Republic" <?php if($redefaultCountry == "Dominican Republic") print 'selected="selected"'; ?> >Dominican Republic</option>
<option value="East Timor" <?php if($redefaultCountry == "East Timor") print 'selected="selected"'; ?> >East Timor</option>
<option value="Ecuador" <?php if($redefaultCountry == "Ecuador") print 'selected="selected"'; ?> >Ecuador</option>
<option value="Egypt" <?php if($redefaultCountry == "Egypt") print 'selected="selected"'; ?> >Egypt</option>
<option value="El Salvador" <?php if($redefaultCountry == "El Salvador") print 'selected="selected"'; ?> >El Salvador</option>
<option value="Equatorial Guinea" <?php if($redefaultCountry == "Equatorial Guinea") print 'selected="selected"'; ?> >Equatorial Guinea</option>
<option value="Eritrea" <?php if($redefaultCountry == "Eritrea") print 'selected="selected"'; ?> >Eritrea</option>

<option value="Estonia" <?php if($redefaultCountry == "Estonia") print 'selected="selected"'; ?> >Estonia</option>
<option value="Ethiopia" <?php if($redefaultCountry == "Ethiopia") print 'selected="selected"'; ?> >Ethiopia</option>
<option value="Falkland Islands" <?php if($redefaultCountry == "Falkland Islands") print 'selected="selected"'; ?> >Falkland Islands</option>
<option value="Faroe Islands" <?php if($redefaultCountry == "Faroe Islands") print 'selected="selected"'; ?> >Faroe Islands</option>
<option value="Fiji" <?php if($redefaultCountry == "Fiji") print 'selected="selected"'; ?> >Fiji</option>
<option value="Finland" <?php if($redefaultCountry == "Finland") print 'selected="selected"'; ?> >Finland</option>
<option value="<option >France" <?php if($redefaultCountry == "<option >France") print 'selected="selected"'; ?> ><option >France</option>
<option value="French Guiana" <?php if($redefaultCountry == "French Guiana") print 'selected="selected"'; ?> >French Guiana</option>

<option value="French Polynesia" <?php if($redefaultCountry == "French Polynesia") print 'selected="selected"'; ?> >French Polynesia</option>
<option value="French Southern Territories" <?php if($redefaultCountry == "French Southern Territories") print 'selected="selected"'; ?> >French Southern Territories</option>
<option value="Gabon" <?php if($redefaultCountry == "Gabon") print 'selected="selected"'; ?> >Gabon</option>
<option value="Gambia" <?php if($redefaultCountry == "Gambia") print 'selected="selected"'; ?> >Gambia</option>
<option value="Georgia" <?php if($redefaultCountry == "Georgia") print 'selected="selected"'; ?> >Georgia</option>
<option value="<option >Germany" <?php if($redefaultCountry == "<option >Germany") print 'selected="selected"'; ?> ><option >Germany</option>
<option value="Ghana" <?php if($redefaultCountry == "Ghana") print 'selected="selected"'; ?> >Ghana</option>
<option value="Gibraltar" <?php if($redefaultCountry == "Gibraltar") print 'selected="selected"'; ?> >Gibraltar</option>

<option value="Greece" <?php if($redefaultCountry == "Greece") print 'selected="selected"'; ?> >Greece</option>
<option value="Greenland" <?php if($redefaultCountry == "Greenland") print 'selected="selected"'; ?> >Greenland</option>
<option value="Grenada" <?php if($redefaultCountry == "Grenada") print 'selected="selected"'; ?> >Grenada</option>
<option value="Guadeloupe" <?php if($redefaultCountry == "Guadeloupe") print 'selected="selected"'; ?> >Guadeloupe</option>
<option value="Guam" <?php if($redefaultCountry == "Guam") print 'selected="selected"'; ?> >Guam</option>
<option value="Guatemala" <?php if($redefaultCountry == "Guatemala") print 'selected="selected"'; ?> >Guatemala</option>
<option value="Guinea" <?php if($redefaultCountry == "Guinea") print 'selected="selected"'; ?> >Guinea</option>
<option value="Guinea-Bissau" <?php if($redefaultCountry == "Guinea-Bissau") print 'selected="selected"'; ?> >Guinea-Bissau</option>
<option value="Guyana" <?php if($redefaultCountry == "Guyana") print 'selected="selected"'; ?> >Guyana</option>

<option value="Haiti" <?php if($redefaultCountry == "Haiti") print 'selected="selected"'; ?> >Haiti</option>
<option value="Heard and McDonald Islands" <?php if($redefaultCountry == "Heard and McDonald Islands") print 'selected="selected"'; ?> >Heard and McDonald Islands</option>
<option value="Honduras" <?php if($redefaultCountry == "Honduras") print 'selected="selected"'; ?> >Honduras</option>
<option value="Hong Kong" <?php if($redefaultCountry == "Hong Kong") print 'selected="selected"'; ?> >Hong Kong</option>
<option value="Hungary" <?php if($redefaultCountry == "Hungary") print 'selected="selected"'; ?> >Hungary</option>
<option value="Iceland" <?php if($redefaultCountry == "Iceland") print 'selected="selected"'; ?> >Iceland</option>
<option value="India" <?php if($redefaultCountry == "India") print 'selected="selected"'; ?> >India</option>
<option value="Indonesia" <?php if($redefaultCountry == "Indonesia") print 'selected="selected"'; ?> >Indonesia</option>
<option value="<!-- copyright Felgall Pty Ltd -->Iran" <?php if($redefaultCountry == "<!-- copyright Felgall Pty Ltd -->Iran") print 'selected="selected"'; ?> ><!-- copyright Felgall Pty Ltd -->Iran</option>

<option value="Iraq" <?php if($redefaultCountry == "Iraq") print 'selected="selected"'; ?> >Iraq</option>
<option value="Ireland" <?php if($redefaultCountry == "Ireland") print 'selected="selected"'; ?> >Ireland</option>
<option value="Israel" <?php if($redefaultCountry == "Israel") print 'selected="selected"'; ?> >Israel</option>
<option value="Italy" <?php if($redefaultCountry == "Italy") print 'selected="selected"'; ?> >Italy</option>
<option value="Jamaica" <?php if($redefaultCountry == "Jamaica") print 'selected="selected"'; ?> >Jamaica</option>
<option value="Japan" <?php if($redefaultCountry == "Japan") print 'selected="selected"'; ?> >Japan</option>
<option value="Jordan" <?php if($redefaultCountry == "Jordan") print 'selected="selected"'; ?> >Jordan</option>
<option value="Kazakhstan" <?php if($redefaultCountry == "Kazakhstan") print 'selected="selected"'; ?> >Kazakhstan</option>
<option value="Kenya" <?php if($redefaultCountry == "Kenya") print 'selected="selected"'; ?> >Kenya</option>

<option value="Kiribati" <?php if($redefaultCountry == "Kiribati") print 'selected="selected"'; ?> >Kiribati</option>
<option value="Korea (north)" <?php if($redefaultCountry == "Korea (north)") print 'selected="selected"'; ?> >Korea (north)</option>
<option value="Korea (south)" <?php if($redefaultCountry == "Korea (south)") print 'selected="selected"'; ?> >Korea (south)</option>
<option value="Kuwait" <?php if($redefaultCountry == "Kuwait") print 'selected="selected"'; ?> >Kuwait</option>
<option value="Kyrgyzstan" <?php if($redefaultCountry == "Kyrgyzstan") print 'selected="selected"'; ?> >Kyrgyzstan</option>
<option value="Lao People's Democratic Republic" <?php if($redefaultCountry == "Lao People's Democratic Republic") print 'selected="selected"'; ?> >Lao People's Democratic Republic</option>
<option value="Latvia" <?php if($redefaultCountry == "Latvia") print 'selected="selected"'; ?> >Latvia</option>
<option value="Lebanon" <?php if($redefaultCountry == "Lebanon") print 'selected="selected"'; ?> >Lebanon</option>
<option value="Lesotho" <?php if($redefaultCountry == "Lesotho") print 'selected="selected"'; ?> >Lesotho</option>

<option value="Liberia" <?php if($redefaultCountry == "Liberia") print 'selected="selected"'; ?> >Liberia</option>
<option value="Libyan Arab Jamahiriya" <?php if($redefaultCountry == "Libyan Arab Jamahiriya") print 'selected="selected"'; ?> >Libyan Arab Jamahiriya</option>
<option value="Liechtenstein" <?php if($redefaultCountry == "Liechtenstein") print 'selected="selected"'; ?> >Liechtenstein</option>
<option value="Lithuania" <?php if($redefaultCountry == "Lithuania") print 'selected="selected"'; ?> >Lithuania</option>
<option value="Luxembourg" <?php if($redefaultCountry == "Luxembourg") print 'selected="selected"'; ?> >Luxembourg</option>
<option value="Macao" <?php if($redefaultCountry == "Macao") print 'selected="selected"'; ?> >Macao</option>
<option value="Macedonia, Former Yugoslav Republic Of" <?php if($redefaultCountry == "Macedonia, Former Yugoslav Republic Of") print 'selected="selected"'; ?> >Macedonia, Former Yugoslav Republic Of</option>
<option value="Madagascar" <?php if($redefaultCountry == "Madagascar") print 'selected="selected"'; ?> >Madagascar</option>

<option value="Malawi" <?php if($redefaultCountry == "Malawi") print 'selected="selected"'; ?> >Malawi</option>
<option value="Malaysia" <?php if($redefaultCountry == "Malaysia") print 'selected="selected"'; ?> >Malaysia</option>
<option value="Maldives" <?php if($redefaultCountry == "Maldives") print 'selected="selected"'; ?> >Maldives</option>
<option value="Mali" <?php if($redefaultCountry == "Mali") print 'selected="selected"'; ?> >Mali</option>
<option value="Malta" <?php if($redefaultCountry == "Malta") print 'selected="selected"'; ?> >Malta</option>
<option value="Marshall Islands" <?php if($redefaultCountry == "Marshall Islands") print 'selected="selected"'; ?> >Marshall Islands</option>
<option value="Martinique" <?php if($redefaultCountry == "Martinique") print 'selected="selected"'; ?> >Martinique</option>
<option value="Mauritania" <?php if($redefaultCountry == "Mauritania") print 'selected="selected"'; ?> >Mauritania</option>
<option value="Mauritius" <?php if($redefaultCountry == "Mauritius") print 'selected="selected"'; ?> >Mauritius</option>

<option value="Mayotte" <?php if($redefaultCountry == "Mayotte") print 'selected="selected"'; ?> >Mayotte</option>
<option value="Mexico" <?php if($redefaultCountry == "Mexico") print 'selected="selected"'; ?> >Mexico</option>
<option value="Micronesia" <?php if($redefaultCountry == "Micronesia") print 'selected="selected"'; ?> >Micronesia</option>
<option value="Moldova" <?php if($redefaultCountry == "Moldova") print 'selected="selected"'; ?> >Moldova</option>
<option value="Monaco" <?php if($redefaultCountry == "Monaco") print 'selected="selected"'; ?> >Monaco</option>
<option value="Mongolia" <?php if($redefaultCountry == "Mongolia") print 'selected="selected"'; ?> >Mongolia</option>
<option value="Montenegro" <?php if($redefaultCountry == "Montenegro") print 'selected="selected"'; ?> >Montenegro</option>
<option value="Montserrat" <?php if($redefaultCountry == "Montserrat") print 'selected="selected"'; ?> >Montserrat</option>
<option value="Morocco" <?php if($redefaultCountry == "Morocco") print 'selected="selected"'; ?> >Morocco</option>

<option value="Mozambique" <?php if($redefaultCountry == "Mozambique") print 'selected="selected"'; ?> >Mozambique</option>
<option value="Myanmar" <?php if($redefaultCountry == "Myanmar") print 'selected="selected"'; ?> >Myanmar</option>
<option value="Namibia" <?php if($redefaultCountry == "Namibia") print 'selected="selected"'; ?> >Namibia</option>
<option value="Nauru" <?php if($redefaultCountry == "Nauru") print 'selected="selected"'; ?> >Nauru</option>
<option value="Nepal" <?php if($redefaultCountry == "Nepal") print 'selected="selected"'; ?> >Nepal</option>
<option value="Netherlands" <?php if($redefaultCountry == "Netherlands") print 'selected="selected"'; ?> >Netherlands</option>
<option value="Netherlands Antilles" <?php if($redefaultCountry == "Netherlands Antilles") print 'selected="selected"'; ?> >Netherlands Antilles</option>
<option value="New Caledonia" <?php if($redefaultCountry == "New Caledonia") print 'selected="selected"'; ?> >New Caledonia</option>
<option value="<option >New Zealand" <?php if($redefaultCountry == "<option >New Zealand") print 'selected="selected"'; ?> ><option >New Zealand</option>

<option value="Nicaragua" <?php if($redefaultCountry == "Nicaragua") print 'selected="selected"'; ?> >Nicaragua</option>
<option value="Niger" <?php if($redefaultCountry == "Niger") print 'selected="selected"'; ?> >Niger</option>
<option value="Nigeria" <?php if($redefaultCountry == "Nigeria") print 'selected="selected"'; ?> >Nigeria</option>
<option value="Niue" <?php if($redefaultCountry == "Niue") print 'selected="selected"'; ?> >Niue</option>
<option value="Norfolk Island" <?php if($redefaultCountry == "Norfolk Island") print 'selected="selected"'; ?> >Norfolk Island</option>
<option value="Northern Mariana Islands" <?php if($redefaultCountry == "Northern Mariana Islands") print 'selected="selected"'; ?> >Northern Mariana Islands</option>
<option value="Norway" <?php if($redefaultCountry == "Norway") print 'selected="selected"'; ?> >Norway</option>
<option value="Oman" <?php if($redefaultCountry == "Oman") print 'selected="selected"'; ?> >Oman</option>
<option value="Pakistan" <?php if($redefaultCountry == "Pakistan") print 'selected="selected"'; ?> >Pakistan</option>

<option value="Palau" <?php if($redefaultCountry == "Palau") print 'selected="selected"'; ?> >Palau</option>
<option value="Palestinian Territories" <?php if($redefaultCountry == "Palestinian Territories") print 'selected="selected"'; ?> >Palestinian Territories</option>
<option value="Panama" <?php if($redefaultCountry == "Panama") print 'selected="selected"'; ?> >Panama</option>
<option value="Papua New Guinea" <?php if($redefaultCountry == "Papua New Guinea") print 'selected="selected"'; ?> >Papua New Guinea</option>
<option value="Paraguay" <?php if($redefaultCountry == "Paraguay") print 'selected="selected"'; ?> >Paraguay</option>
<option value="Peru" <?php if($redefaultCountry == "Peru") print 'selected="selected"'; ?> >Peru</option>
<option value="Philippines" <?php if($redefaultCountry == "Philippines") print 'selected="selected"'; ?> >Philippines</option>
<option value="Pitcairn" <?php if($redefaultCountry == "Pitcairn") print 'selected="selected"'; ?> >Pitcairn</option>
<option value="Poland" <?php if($redefaultCountry == "Poland") print 'selected="selected"'; ?> >Poland</option>

<option value="Portugal" <?php if($redefaultCountry == "Portugal") print 'selected="selected"'; ?> >Portugal</option>
<option value="Puerto Rico" <?php if($redefaultCountry == "Puerto Rico") print 'selected="selected"'; ?> >Puerto Rico</option>
<option value="Qatar" <?php if($redefaultCountry == "Qatar") print 'selected="selected"'; ?> >Qatar</option>
<option value="R&eacute;union" <?php if($redefaultCountry == "R&eacute;union") print 'selected="selected"'; ?> >R&eacute;union</option>
<option value="Romania" <?php if($redefaultCountry == "Romania") print 'selected="selected"'; ?> >Romania</option>
<option value="Russian Federation" <?php if($redefaultCountry == "Russian Federation") print 'selected="selected"'; ?> >Russian Federation</option>
<option value="Rwanda" <?php if($redefaultCountry == "Rwanda") print 'selected="selected"'; ?> >Rwanda</option>
<option value="Saint Helena" <?php if($redefaultCountry == "Saint Helena") print 'selected="selected"'; ?> >Saint Helena</option>

<option value="Saint Kitts and Nevis" <?php if($redefaultCountry == "Saint Kitts and Nevis") print 'selected="selected"'; ?> >Saint Kitts and Nevis</option>
<option value="Saint Lucia" <?php if($redefaultCountry == "Saint Lucia") print 'selected="selected"'; ?> >Saint Lucia</option>
<option value="Saint Pierre and Miquelon" <?php if($redefaultCountry == "Saint Pierre and Miquelon") print 'selected="selected"'; ?> >Saint Pierre and Miquelon</option>
<option value="Saint Vincent and the Grenadines" <?php if($redefaultCountry == "Saint Vincent and the Grenadines") print 'selected="selected"'; ?> >Saint Vincent and the Grenadines</option>
<option value="Samoa" <?php if($redefaultCountry == "Samoa") print 'selected="selected"'; ?> >Samoa</option>
<option value="San Marino" <?php if($redefaultCountry == "San Marino") print 'selected="selected"'; ?> >San Marino</option>
<option value="Sao Tome and Principe" <?php if($redefaultCountry == "Sao Tome and Principe") print 'selected="selected"'; ?> >Sao Tome and Principe</option>
<option value="<!-- copyright Felgall Pty Ltd -->Saudi Arabia" <?php if($redefaultCountry == "<!-- copyright Felgall Pty Ltd -->Saudi Arabia") print 'selected="selected"'; ?> ><!-- copyright Felgall Pty Ltd -->Saudi Arabia</option>

<option value="Senegal" <?php if($redefaultCountry == "Senegal") print 'selected="selected"'; ?> >Senegal</option>
<option value="Serbia" <?php if($redefaultCountry == "Serbia") print 'selected="selected"'; ?> >Serbia</option>
<option value="Seychelles" <?php if($redefaultCountry == "Seychelles") print 'selected="selected"'; ?> >Seychelles</option>
<option value="Sierra Leone" <?php if($redefaultCountry == "Sierra Leone") print 'selected="selected"'; ?> >Sierra Leone</option>
<option value="Singapore" <?php if($redefaultCountry == "Singapore") print 'selected="selected"'; ?> >Singapore</option>
<option value="Slovakia" <?php if($redefaultCountry == "Slovakia") print 'selected="selected"'; ?> >Slovakia</option>
<option value="Slovenia" <?php if($redefaultCountry == "Slovenia") print 'selected="selected"'; ?> >Slovenia</option>
<option value="Solomon Islands" <?php if($redefaultCountry == "Solomon Islands") print 'selected="selected"'; ?> >Solomon Islands</option>
<option value="Somalia" <?php if($redefaultCountry == "Somalia") print 'selected="selected"'; ?> >Somalia</option>

<option value="South Africa" <?php if($redefaultCountry == "South Africa") print 'selected="selected"'; ?> >South Africa</option>
<option value="South Georgia and the South Sandwich Islands" <?php if($redefaultCountry == "South Georgia and the South Sandwich Islands") print 'selected="selected"'; ?> >South Georgia and the South Sandwich Islands</option>
<option value="Spain" <?php if($redefaultCountry == "Spain") print 'selected="selected"'; ?> >Spain</option>
<option value="Sri Lanka" <?php if($redefaultCountry == "Sri Lanka") print 'selected="selected"'; ?> >Sri Lanka</option>
<option value="Sudan" <?php if($redefaultCountry == "Sudan") print 'selected="selected"'; ?> >Sudan</option>
<option value="Suriname" <?php if($redefaultCountry == "Suriname") print 'selected="selected"'; ?> >Suriname</option>
<option value="Svalbard and Jan Mayen Islands" <?php if($redefaultCountry == "Svalbard and Jan Mayen Islands") print 'selected="selected"'; ?> >Svalbard and Jan Mayen Islands</option>
<option value="Swaziland" <?php if($redefaultCountry == "Swaziland") print 'selected="selected"'; ?> >Swaziland</option>
<option value="Sweden" <?php if($redefaultCountry == "Sweden") print 'selected="selected"'; ?> >Sweden</option>

<option value="Switzerland" <?php if($redefaultCountry == "Switzerland") print 'selected="selected"'; ?> >Switzerland</option>
<option value="Syria" <?php if($redefaultCountry == "Syria") print 'selected="selected"'; ?> >Syria</option>
<option value="Taiwan" <?php if($redefaultCountry == "Taiwan") print 'selected="selected"'; ?> >Taiwan</option>
<option value="Tajikistan" <?php if($redefaultCountry == "Tajikistan") print 'selected="selected"'; ?> >Tajikistan</option>
<option value="Tanzania" <?php if($redefaultCountry == "Tanzania") print 'selected="selected"'; ?> >Tanzania</option>
<option value="Thailand" <?php if($redefaultCountry == "Thailand") print 'selected="selected"'; ?> >Thailand</option>
<option value="Togo" <?php if($redefaultCountry == "Togo") print 'selected="selected"'; ?> >Togo</option>
<option value="Tokelau" <?php if($redefaultCountry == "Tokelau") print 'selected="selected"'; ?> >Tokelau</option>
<option value="Tonga" <?php if($redefaultCountry == "Tonga") print 'selected="selected"'; ?> >Tonga</option>

<option value="Trinidad and Tobago" <?php if($redefaultCountry == "Trinidad and Tobago") print 'selected="selected"'; ?> >Trinidad and Tobago</option>
<option value="Tunisia" <?php if($redefaultCountry == "Tunisia") print 'selected="selected"'; ?> >Tunisia</option>
<option value="Turkey" <?php if($redefaultCountry == "Turkey") print 'selected="selected"'; ?> >Turkey</option>
<option value="Turkmenistan" <?php if($redefaultCountry == "Turkmenistan") print 'selected="selected"'; ?> >Turkmenistan</option>
<option value="Turks and Caicos Islands" <?php if($redefaultCountry == "Turks and Caicos Islands") print 'selected="selected"'; ?> >Turks and Caicos Islands</option>
<option value="Tuvalu" <?php if($redefaultCountry == "Tuvalu") print 'selected="selected"'; ?> >Tuvalu</option>
<option value="Uganda" <?php if($redefaultCountry == "Uganda") print 'selected="selected"'; ?> >Uganda</option>
<option value="Ukraine" <?php if($redefaultCountry == "Ukraine") print 'selected="selected"'; ?> >Ukraine</option>
<option value="United Arab Emirates" <?php if($redefaultCountry == "United Arab Emirates") print 'selected="selected"'; ?> >United Arab Emirates</option>

<option value="<option >United Kingdom" <?php if($redefaultCountry == "<option >United Kingdom") print 'selected="selected"'; ?> ><option >United Kingdom</option>
<option value="<option >United States of America" <?php if($redefaultCountry == "<option >United States of America") print 'selected="selected"'; ?> ><option >United States of America</option>
<option value="Uruguay" <?php if($redefaultCountry == "Uruguay") print 'selected="selected"'; ?> >Uruguay</option>
<option value="Uzbekistan" <?php if($redefaultCountry == "Uzbekistan") print 'selected="selected"'; ?> >Uzbekistan</option>
<option value="Vanuatu" <?php if($redefaultCountry == "Vanuatu") print 'selected="selected"'; ?> >Vanuatu</option>
<option value="Vatican City" <?php if($redefaultCountry == "Vatican City") print 'selected="selected"'; ?> >Vatican City</option>
<option value="Venezuela" <?php if($redefaultCountry == "Venezuela") print 'selected="selected"'; ?> >Venezuela</option>
<option value="Vietnam" <?php if($redefaultCountry == "Vietnam") print 'selected="selected"'; ?> >Vietnam</option>

<option value="Virgin Islands (British)" <?php if($redefaultCountry == "Virgin Islands (British)") print 'selected="selected"'; ?> >Virgin Islands (British)</option>
<option value="Virgin Islands (US)" <?php if($redefaultCountry == "Virgin Islands (US)") print 'selected="selected"'; ?> >Virgin Islands (US)</option>
<option value="Wallis and Futuna Islands" <?php if($redefaultCountry == "Wallis and Futuna Islands") print 'selected="selected"'; ?> >Wallis and Futuna Islands</option>
<option value="Western Sahara" <?php if($redefaultCountry == "Western Sahara") print 'selected="selected"'; ?> >Western Sahara</option>
<option value="Yemen" <?php if($redefaultCountry == "Yemen") print 'selected="selected"'; ?> >Yemen</option>
<option value="Zaire" <?php if($redefaultCountry == "Zaire") print 'selected="selected"'; ?> >Zaire</option>
<option value="Zambia" <?php if($redefaultCountry == "Zambia") print 'selected="selected"'; ?> >Zambia</option>
<option value="Zimbabwe" <?php if($redefaultCountry == "Zimbabwe") print 'selected="selected"'; ?> >Zimbabwe</option>
</select>
